#define string
hero = 'Super Man'

#prints string
print(hero) 

#define manipulated string
string = "S^U^P^E^R M^A^N" 

#print manipulated string
print(string) 

replace_string = string.replace("^", " ")

#exclude ^ character and include space
print(replace_string) 

string = string.lower()
#print string as lower case
print(string) 








