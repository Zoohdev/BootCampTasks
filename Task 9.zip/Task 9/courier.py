#Program calculates the cost of sending a parcel
#Prompt user questions
#Calculates price,delivery and insurance of parcel
#Total cost calculated after user prompts

#asks user for price of package uses float for decimal values
price = float(input("What is the price of your package in ZAR?"))

#determines user price input
distance = int(input("What is the total distance of the delivery in kms?"))

#Cost varies in terms of insurance
nature = input("What is the nature of your parcel? Perishable or Non-Perishable?")

full_insurance = float(50.00)
limited_insurance = float(25.00)
total_cost1 = float((price) + (full_insurance))
total_cost2 = float((price) + (limited_insurance))
if nature == "Perishable":
    print("Your package will cost R{} including insurance.".format(total_cost1))

else:

          print("The total cost of your package is R{}.".format(total_cost2))



priority =float(100.00)
air = float(0.36)
standard = float(25.00)
freight = float(0.25)
total_cost3 = float((price) + (priority) + ((distance)*(air)))
total_cost4 = float((price) + (standard)) + ((distance)*(freight))
experience = input("Would you like priority on your package which includes air delivery or standard delivery by freight?(Priority or Standard)")
if experience == "Priority":
     print("The total cost of your package is R{}.".format(total_cost3))


else:


          print("The total cost of your package is R{}.".format(total_cost4))

gift_price = float(15.00)
gift = input("Would you like to include a gift?(Yes or No)")
if gift == "Yes":
    print("We have added a gift of R{} to your purchase. Thank you for shopping with us.".format(gift_price))


else:

        print("No gift has been added.Thank you for using our services and have a prosperous day.Goodbye.")

          
         

    
              


            







          
    
