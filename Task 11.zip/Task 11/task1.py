#Program declares three integers and compares their values.
#If and elif statements used to determine conditionals.

num1 = 4
num2 = 3
num3 = 12


if num1 > num3:
    print("4 cannot be bigger than 12")
    
elif num3 > num1:
    print("That's correct 12 is bigger than 4")
    
if num1 % 2 != 0:
    print("That cannot be true since 4 is divisible by 2")

elif num1 % 2 == 0:
    print("4 is divisible by 2 which makes it an even number.")

if num1 < num3 :
    print("{} is bigger than {}.".format(num3,num1))
    

if  num1 > num2 :
    print("{} is bigger than {}.".format(num1,num2))
    
elif num2 < num3 :
    print("{} is bigger than {}.".format(num3,num2))
 #prints in ascending order    
print("The numbers in accending order are {},{},{}.".format(num3,num1,num2))
          
    
