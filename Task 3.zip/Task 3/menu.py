
item1 = input("Order your favorite food: ")


print("Perfect Choice Order Confirmed you have ordered" + "" + item1)


print("Ready for your next order?")

item2 = input("Order your favorite food: ")


print("YUM! you have ordered" + "" + item2 )

print("Still hungry?!")

item3 = input("Order your meal: ")

print("Great Choice you have ordered" + "" + item3)


print("Thanks for using our services Bon Apetit!")




