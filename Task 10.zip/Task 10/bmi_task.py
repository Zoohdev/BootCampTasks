#Program calculates user's body mass index.
#inputs weight and height and stores them as floats
#Conditionals determine if user is healthy,overweight or obese

weight = float(input("Please enter your weight in kg:  "))


height = float(input("Please enter your height in m:  "))

#bmi calculator formula
bmi = weight / (height * height)

under_weight = float(18.5)

if bmi >= 30:
            val = 30
            print(f"Your body mass index of {val} indicates obesity.")


elif bmi >= 25 :
            val = 25
            print(f"According to your body mass index of {val} you are overweight.")

elif bmi >= float(18.5) :

            print("You have a normal body mass index and are healthy.")

else:
        val = 18.5
        print(f"Your BMI is lower than {val} and you are underweight.")
 
