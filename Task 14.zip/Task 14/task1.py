#imports
import math

#user input
num = int(input())

#for loop displays timetables from 0 to 12
for i in range(0, 13):
   print(num, 'x', i, '=', num*i)
