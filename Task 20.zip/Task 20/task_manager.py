#Only admin can register user
#includes option to display statistice

login = False
username = input("Please enter your username: ")
password = input("Please enter your password: ")


with open("user.txt", "r+") as user_file:
    while login == False:
        for line in user_file:
            split_line = line.split(",")
           valid_user = split_line[0].strip()
            valid_password= split_line[1].strip()
            if username == valid_user and password == valid_password:
                print("Successfully logged in.")
                login = True
                
            
        user_file.seek(0)
        
# If incorrect credentials request correct credentials
        if not login:
            print("Incorrect credentials.")
            username = input("Enter username: ")
            password = input("Enter password: ")

# If username and password is correct, display the menu selection
while True:
    print("\nPlease select of the following options: ")
    print("r - register user") 
    print("a - add task") 
    print("va - view all tasks") 
    print("vm - view my tasks") 
    print("e - exit")
    if username == "admin":
        print("ds - display statistics")
        
     choice = input("What would you like to do: ").lower()
                    

# If 'r' is chosen, register a new user, ask for a new password and username  
# Confirm the password and write the information to the user.txt file

# Allow only admin for registering and statistics functionality
    if choice == "r":
        if username == "admin":
            print("Register New User")
            new_user = input("Please input the new user name: ")
            user_file = open("user.txt", "r+")    
            duplicate_found = False
            for line in file:
                split_line = line.split(",")
                user_check = split_line[0].strip()
                if new_user == user_check:
                    print("Username already taken")
                    duplicate_found = True
        
# Checks passwords and confirms
            new_password = input("Please input your password for the new user: ")
            if new_password == input("Confirm password: "):
                user_file.write("\n" + new_user + ", ")
                user_file.write(new_password)
                user_file.close()
                print("New user and password added")  
            else:
                print("Password doesn't match.")

        else:
            print("\nOnly administrators can register users")
        

    if choice == "a":
        print("Add a new task")
        with open("user.txt") as file:
            assigned_person = input("Enter user task is assigned to: ")
            task_title = input("Enter task title: ")
            task_description = input("Enter task description: ")
            date_assigned = input("Please input today's date: ")
            task_due = input("Please input the task deadline: ")
            task_complete = input("Is the task completed? (Yes or No): ")
            with open("tasks.txt", "a") as task1:
                task1.write("\n" + assigned_person + ", " + task_title + ", " + task_description + ", " + date_assigned + ", " + task_due + ", " + task_complete)
                print("New task added")



    if choice == "va":
        task_file = open("tasks.txt", "r+")
        for line in task_file:
         task = line.split(",")
         print("\nTask Manager: " + task[0] + "\n" + "Task Title: " + task[1] + "\n" + "Task Description: " + task[2] + "\n" + "Date Assigned: " + task[3] + "\n" + "Deadline: " + task[4] + "\n" + "Complete(Yes or No): " + task[5])

                    

    if choice == "vm":
        task_count = 0
        task_file = open("tasks.txt", "r+")
        print("")
        for line in task_file:
            task = line.split(", ")
            if task[0] == username:
              task_count+=1
              print("\nTask manager: " + task[0] + "\n" + "Task title: " + task[1] + "\n" + "Task details: " + task[2] + "\n" + "Date assigned: " + task[3] + "\n" + "Deadline: " + task[4] + "\n" + "Complete(Yes or No): " + task[5])



    if choice == "ds":
        print("Total number of users:")
        user_file = open("user.txt", "r+")
        for line in file:
            user_file = user_file.readlines()
            print(len(user_file))

        print("Total number of tasks:")
        task_file = open("tasks.txt", "r+")
        for line in task_file:    
            task_file = task_file.readlines()
            print(len(task_file))
                            
# If "e" is chosen, exit the program
    if choice == "e":
        break
            