#prints out all numbers from 1 to 1000
#prints all even numbers in the range
for n in (1,2):
    print(*range(n,1001,n), sep='\n')

