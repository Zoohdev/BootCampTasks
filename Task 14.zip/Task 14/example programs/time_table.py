for x in range(1, 6):
    for y in range(1, 6):
        print('{} * {} = {}'.format(x, y, x*y))
    print("")
