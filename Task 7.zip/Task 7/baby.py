num = int(input('Enter the year you were born: '))#Enter birth year

print(num)#prints input

if num <= 2003:
    print('Congrats, you are old enough!')#Satisfies Conditional

if num >= 2003:
    print('Its past your bed time.')#Does not satisfy conditional
    



