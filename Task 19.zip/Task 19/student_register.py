output_file = open("student_register.txt","w")
user = int(input('How many students are registering?: '))

for i in range(user):
   i=input("Enter your ID number: ")

output_file.write("Identity numbers" + " " + i + "\n")

output_file.close()
   
