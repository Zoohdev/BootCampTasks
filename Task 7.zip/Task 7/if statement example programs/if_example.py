#This is an example Python program demonstrating if statements.

NAME = input("Enter your name: \n")

if len(NAME) == 0:
	print ("You didn't enter anything.")

if len(NAME) > 10:
		print ("You've got a long name.")

print(NAME)

#Run this program. Change your input to get different outputs due to the if statements.



