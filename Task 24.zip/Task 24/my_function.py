weekdays = {
    "Monday":0,
    "Tuesday":1,
    "Wednesday":2,
    "Thursday":3,
    "Friday":4,
    "Saturday":5,
    "Sunday":6
}

for day in weekdays:
   print(day)

def replace(sentence):

    l = sentence.split(' ')

    list_odd = l[0::2]
    print(list_odd)
    final_list = []

    for word in list_odd:
        final_list.append(word)
        final_list.append('hello')

    final_string = " ".join(final_list)

    print(final_string)
replace("\The quick brown fox jumps over the lazy dog.")
