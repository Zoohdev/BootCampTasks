#Prompts for 10 floats and integers from user
#Appends them to an empty list
#Prints out the sum
import math
from statistics import mean
from statistics import median

print("Please enter 10 numbers with or without decimals\n")

num_list = []
for num in range(10):
    list_float = float(input("Enter a number:"))
    num_list.append(list_float)
print("The sum of your numbers is:\n")
print(sum(num_list))

max_value = max(num_list) 
max_index = num_list.index(max_value)
print("The maximum index of your numbers is:")
print(max_index)

min_value = min(num_list) 
min_index = num_list.index(min_value)
print("The minimum index of your numbers is:")
print(min_index)

list_average = mean(num_list) 
print("The average value of your numbers is:") 
print(round(list_average,2))

list_median = median(num_list)
print("The median value of your numbers is:") 
print(list_median)

