#User enters integer
#Determine if integer is divisible by prime numbers 2 and 5
#Displays results using if and elif statements

num = int(input("Enter integer: "))

if num % 2 == 0 and num % 5 == 0 :
    print("Integer is divisible by both 2 and 5.")

elif num % 2 == 0 and num % 5 != 0 :
        print("Integer is even and cannot divide into 5.")
        
elif num % 2 != 0 and num % 5 == 0 :
    print("Integer is divisible by 5 but not 2")

elif num % 2 == 0 or num % 5 == 0 :
        print("Integer goes into either 2 or 5.")

elif num % 2 != 0 and num % 5 != 0 :
        print("Integer is not divisible into prime numbers 2 and 5.")

    


