num = int(input('Enter an integer: ')) #Input integer

print('The number you have entered is {}.'.format(num)) #print entered value

if num % 2 == 0: #conditional for numbers that can divide into 2
    print('You have entered an even number.') #prints 'You have entered an even number.'

if num % 2 != 0: #numbers cannot divide into 2
   print('You have entered an odd number.') #prints 'You have entered an odd number.'


