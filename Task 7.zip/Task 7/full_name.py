name = input('Please enter your full name: ') #input full name

len_char = int(len(x)) #calculates length of characters

print( 'Your full name has {} characters.'.format(len_char)) #prints 'Your full name has x characters.

if len_char <= 4: #sets conditional
    print('You have not entered anything.Please enter your full name') #conditional vale not met

if len_char > 4:
    print('Thank you for entering your name') #satisfied conditional

if len_char > 25:
    print('Please make sure that you have only entered your full name')







        

