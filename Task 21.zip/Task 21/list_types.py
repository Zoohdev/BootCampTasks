
friends_names = ["Nthabiseng","Priya","Munaka"]

first_name = friends_names[0]

last_name = friends_names[-1]

print("The first name on the list is {}.".format(first_name))

print("The last name on the list is {}.".format(last_name))

friends_age = [22 ,42,29]

for age in friends_age:
    first_age = friends_age[0]
    last_age = friends_age[-1]
    age -= 1
print(" {} is  {} years old.".format(first_name,first_age))
print(" {} is  {} years old.".format(last_name,last_age))

