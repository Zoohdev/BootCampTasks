#Program used to calculate area of foundation of a building
#user inputs dimensions and determines shape
#Calculates dimensions

shape = input("Enter the shape of the foundation: ")

area = 0
#value of pi
pi = 3.14
#calculates area of square
if shape == "square" :
        length = int(input("Enter the length in m: "))
        area = area + (length * length)
        print("The area of the foundation is {} square meters.".format(area))
#calculates area of circle      
elif shape == "circle" :
        radius = int(input("Enter the value of radius in m: "))
        area = area + (pi * radius * radius)
        print("The area of the foundation is {} square meters.".format(area))
 #calculates area of rectangle      
elif shape == "rectangle" :
        length = int(input("Enter the value of length: "))
        width = int(input("Enter the value of width: "))
        area = area + (length * width)
        print("The area of the foundation is {} square meters.".format(area))
  
else:
        print ("Select a valid shape")
       
