#requires user to input names of all pupils in class
#uses while loop to input names until user inputs stop


loop = True
while loop:
     name = input("Enter pupil name: ")
     if name == "Stop":
        loop = False
     num_names = len(name)
     num_names -= 1
     #prints number of names entered after program has been exited
print(num_names)
