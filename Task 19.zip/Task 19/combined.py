#Program merges two textfiles and sorts content in ascending order
#Code implementation found on Geeks4Geeks
numbers_1 = ""
numbers_2 = ""

with open('numbers1.txt') as fp:
    numbers_1 = fp.read()

with open('numbers2.txt') as fp:
    numbers_2 = fp.read()

numbers_1 += "\n"
numbers_1 += numbers_2
  
with open ('all_numbers.txt', 'w') as fp:
    fp.write(numbers_1)

    filenames = ['numbers1.txt', 'numbers2.txt']
  
with open('all_numbers.txt', 'w') as outfile:
  
    
    for names in filenames:
  
       
        with open(names) as infile:
  
            outfile.write(infile.read())
  
        outfile.write("\n")





