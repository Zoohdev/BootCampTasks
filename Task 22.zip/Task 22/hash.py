#Create dictionary of countries and their capital cities
#use print(variable["string"] to print the capital cities
countryMap = {
    "South Africa" : "Pretoria",
    "Nigeria" : "Lagos",
    "United Kingdom" : "London",
    "Sweden" : "Stockholm"
    }

print(countryMap["South Africa"])
print(countryMap["Nigeria"])
print(countryMap["United Kingdom"])
print(countryMap["Sweden"])
