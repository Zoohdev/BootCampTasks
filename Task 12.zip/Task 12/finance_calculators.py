#imports
import math
#prints definition of options
print("investment   - to calculate amount of interest you'll earn on interest")
print("bond     - to calculate the amount you'll have to pay on a home loan")
#input investment or bond
choose = input("Choose either investments or bond from the menu below to proceed:").lower() 
#conditionals for investment options
if choose == "investment":
    P = float(input("How much are you depositing in ZAR?:"))
    r = float(input("What is your interest rate? (as a percentage):"))
    n = float(input("How long is your investment?(in years):"))
    interest = input("Would you like your interest calculated as simple or compounded? (simple or compound)")
  
    #calculates simple interest and sets conditional
    if interest == "simple":
      SI = (P * n * r) / 100
      FV = P + SI
      print("Simple interest : {}".format(SI))
      print("The final value will be R{}.".format(FV))
    #conditional if user prefers compound interest
    elif interest == "compound":
         CI = P * (((1 + (r/(100.0))) ** n))
         val = CI
         #prints final amount using f statement instead of string formatting
         print(f"The final amount on your investment is R{val}.")

    else:
         print("Please enter the correct option.")
#conditional if user chose bond instead of investment
if choose == "bond":
    P= float(input("What is the present value of the house?:"))
    r = float(input("What is your interest rate? (as a percentage):"))
    n = float(input("How long(in months) do you plan to repay the bond?"))
    x = P * (r *(1 + r) ** n  / ((1 + r) **n ) - 1)
    val = x/n
    print(f"Your monthly repayment is R{val}.")

else:
    print("Please enter the correct option.")
             

             
        
