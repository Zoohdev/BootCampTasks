# This example program is meant to demonstrate errors.
 # There are some errors in this program, try run the program by pressing F5.
# Now look at the error messages and find and fix the errors.
#added missing parenthesis(syntax error)
print("Welcome to the error program")
#fixed indentation and added parenthesis(syntax error)
print("\n")
#fixed indentation(syntax errors)
#string not defined(runtime error)
#variable not defined accordingly(logical error)
ageStr = 24
#string is defined as an integer without quotes age variable is uneccesary(logical error)
age = ageStr
#print out age using string formatting instead of "+ age"(syntax +logical error)
print("I am {} years old.".format(age))
#integer defined as string, removed air qoutes and added 4 to years variable 
years = age + 3.5
val = years
#added parenthesis(syntax error) and used f formatting to print out total number of years
print(f"The total number of years: {val}")
#spaced operators and declared variable as the product of the number of months in a year and age
months = years * 12
val = months
print(f"In 4 years and 6, I'll be {val} months old")

#HINT, 330 months is the correct answer

