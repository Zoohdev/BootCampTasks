# This example program is meant to demonstrate errors.
 
# There are some errors in this program, try run the program by pressing F5.
# Now look at the error messages and find and fix the errors.
#added quotes to define string
animal = "Lion"
#fixed indentation
animal_type = "cub"
number_of_teeth = 16
#using string formatting to print and removed full_spec variable
print("This is a {}. It is a {} and it has {} teeth.".format(animal,animal_type,number_of_teeth))

