#program always asks user for a number


n = -1
while True:
    i = int(input("Enter number:"))
    if i == n:
       print("Program is exiting")
       break

nums = []
for n in range(i):
    nums.insert(n, int(input()))

sum = 0
for n in range(i):
    sum = sum+nums[n]

avg = sum/n
print("\nAverage = ", avg)

  

