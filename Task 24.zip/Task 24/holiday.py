#Program calculates cost of a holiday in France
#Define hotel costs
#Define flight costs
#Define car rental
#calculate holiday cost and print
def hotel_cost(num_of_nights):
    return(1540 *(num_of_nights))

def  plane_cost(city):
    plane_costs = {
        "Paris":4567,
        "Marseille":4987,
        "Montpelier":4321
        }
    return plane_costs[city] 

def car_rental(days):
    return(250 *(days))

def holiday_cost(num_of_nights,city,days):
    return (hotel_cost(num_of_nights) + plane_cost(city) + car_rental(days))
 
cost = holiday_cost(num_of_nights=6, city="Paris", days=7)
print("The total budget for your holiday is R{}.".format(cost))
 
