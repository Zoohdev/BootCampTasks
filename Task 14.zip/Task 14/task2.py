#Program determines if year is a leap year or not
# help with range and if formula found on geeks4geeks
#user inputs year then determines for any number of years after

year = int(input("Enter year: "))
num = int(input("How many years would you like to check?"))
last_year = year + num


for year in range(year, last_year):
        
    if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0):
        print ("{} is a leap year".format(year))
    else:
        print ("{} is not a leap year".format(year))
