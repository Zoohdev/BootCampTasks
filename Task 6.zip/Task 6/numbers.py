num1 = int(input('Enter integer: ')) #integer 1

print(num1) #prints first integer

num2 = int(input('Enter integer: ')) #integer 2

print(num2) #prints second integer

num3 = int(input('Enter integer: ')) #integer 3

print(num3) #prints third integer

#calculates sum of three numbers
sum_num = num1 + num2 + num3

difference = num1 - num2

product = num3 * num1

div_num = sum_num / num3

print(sum_num) #prints sum

print(difference) #prints difference between first and second number

print(product) #prints product of third and first number

print(div_num) #prints sum divided by third number

               




