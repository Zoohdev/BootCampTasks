#Programs calculates age control using if, else and elif statements
#User inputs age
#Age stored as int variable

age = int(input('How old are you: '))

#if input is bigger or equal to 18
if age >= 18:
    print("You are old enough.")

#checks if age is bigger than 16 but smaller than 18
elif age>16 and age<18:

        print("Almost there")

#prints if none of the conditions above are met
else:
            print("You're just too young!")
