a = int(input('Enter length of triangle: ')) #input side a
b = int(input('Enter length of triangle: ')) #input side b
c= int(input('Enter length of triangle: '))  #input side c

s = int((a + b + c) / 2)     # calculate the semi perimeter

import math

area = math.sqrt((s*(s-a)*(s-b)*(s-c)) ** 0.5 ) # calculate the area

print(area) #print area

