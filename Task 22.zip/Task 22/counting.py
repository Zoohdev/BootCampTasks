#define string
#place letter and number of times it occurs in string in a dictionary
#print dictionary
string = "google.com"

num_occurences = {
              "g": 2,
              "o" : 3,
              "l" : 1,
              "e" : 1,
              "c" : 1,
              "m" : 1,
              }

print(num_occurences)
