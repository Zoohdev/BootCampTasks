#Program asks user to enter a number
#Uses for loop repetition  to print out even numbers

n = int(input("Enter a number : ")) 
i = 0

while i <= n : # Using while
    if i % 2 == 0:
      print (n)
      i += 1
