a = input('Enter product: ') #Enter first product

print(a) #Prints first product

x = float(input('Enter price ZAR: ')) #Enter price of first product

rounded_x = round(x, 2) #rounds price to 2 decimal places

print(rounded_x) #prints rounded price

b = input('Enter product: ') #Enter second product

print(b) #prints second product

y = float(input('Enter price ZAR: ')) #Enter price of product

rounded_y = round(y, 2) #rounds of price 2

print(rounded_y) #prints price 2 rounded of

c = input('Enter product: ') #Enter third product

print(c) #prints third product

z = float(input('Enter price ZAR: ')) #Enter price of third product

rounded_z = round(z, 2) #rounds of price 3

print(rounded_z) #prints price 3 rounded off

sum = (rounded_x) + (rounded_y) + (rounded_z) #calculates total

rounded_sum = round(sum, 2) #prints total rounded off to two decimal places

print(rounded_sum)#Prints value of total

average = sum/3 #calculates total

rounded_average = round( average, 2) #rounds off average

print(rounded_average) #prints average

print("The total of the product is R{}".format(rounded_sum) + " " +
      "and the average is R{}".format(rounded_average) + ".")
#Prints 'The total of the products is Rx and the average is Ry."








