NUM_DAYS = int(input("How many days did you work this month? "))
PAY_PER_DAY = float(input("How much is your pay per day? "))
SALARY = NUM_DAYS * PAY_PER_DAY
print("My salary for the month is R{}".format(SALARY))
