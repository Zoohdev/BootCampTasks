 #requires user name
user_name = input("Enter your fullname:  ")

#requires user to input age
user_age = input("Enter your age:  ")

#requires user to enter house number
user_address = input("Enter your house number:  ")

#requires user to enter street name
user_address1 = input("Enter your street name:  ")

print("Her name is {}".format(user_name) + "." + "She is {} years old".format(user_age),
      "and she lives on","{}".format(user_address),"{}".format(user_address1) + ".")
#prints "Her name is x. She is y years old and lives on "insert address".
