#Program prompts for two numbers then calculates mean
x = int(input('Enter a number: '))
y = int(input('Enter a number: '))

z = x+y/2
val = z
print (f'The mean/average of the two numbers you have entered is {val}.')

#order of operations miscalculates the mean which makes this a logical error
