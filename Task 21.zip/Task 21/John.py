print("Please enter your name below.")

list_of_names = []
stop_name = "John"
while True:
    name = input("Enter Name: ")
    if name == stop_name:
        break
    list_of_names.append(name)

print("Incorrect Names:")
print(list_of_names)
