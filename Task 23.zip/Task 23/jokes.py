import sys

sys.path.append('/usr/local/lib/python3.7/dist-packages/')

import pyjokes

list_of_jokes = pyjoke.get_joke('en','twister')

for i in range(0, 10):
    print(list_of_jokes[i], sep='\n')


