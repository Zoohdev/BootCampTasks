#set empty lists
#open text document DOB
#set for loop to append data to empty lists
#print Name and Birthdates
name_list =[]
birthdate_list=[]
count = 0


with open('DOB.txt','r+') as f:

 for list in f:
     list=list.split()
     full_name = list[0] + " " + list[1]
     date_of_birth = list[2] + " " + list[3] + " " + list[4]
     count += 0
     name_list.append(full_name)
     birthdate_list.append(date_of_birth)
     print("Name\n" + full_name + "\n\n" + "Birth Date\n" + date_of_birth)
   



        
