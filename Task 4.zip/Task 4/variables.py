number =99

number_str =int(99)

#prints sum of number and string
print(number + int(number_str))

num_hours = int(input("How many hours are in a work week?"))
#requires weekly work hours

print("I work {} hours a week.".format(num_hours))

#input weekly salary
pay_per_week = float(input("How much is your pay per week?"))

#calculates weekly salary
weekly_salary = float(num_hours * pay_per_week)

#prints My weekly slary is Rx per week.
print("My weekly salary is R{} per week.".format(weekly_salary))

#prints value of weekly salary
print("My weekly salary is ZAR: R{}".format(weekly_salary))






