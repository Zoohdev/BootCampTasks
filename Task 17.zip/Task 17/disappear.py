#Program prompts for string from user
#Strips desired characters from string
#Displays new string

string=input("Enter Sentence:")
remove_char= input("Which characters would you like to remove?") 
new=filter(lambda i: i not in remove_char,string) 
new_string="" 
for i in new: 
    new_string+=i 
print(new_string) 
