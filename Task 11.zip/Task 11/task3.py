#program calculates olympic records

#input time for swimming
swimming = int(input("Enter time taken for swimming in seconds:"))

#input time for running               
running  = int(input("Enter time taken for swimming in seconds:"))

#input time for cycling               
cycling  = int(input("Enter time taken for swimming in seconds:"))

#calculates time for the entire triathlon
triathlon = swimming + running + cycling

#player finishes triathlon within qualifying time.
if triathlon < 100 :
               print("You have been awarded provincial colours.")

#player finishes triathlon within 5 minutes of qualification time.
elif triathlon > 100 or triathlon <=105 :
    print("You have been awarded provincial half colours.")

#player finishes triathlon within 10 minutes of qualification time.
elif triathlon > 105 or triathlon <= 110 :
               print("You have been awarded a provincial scroll.")

#player finishes triathlon in more than 10 minutes of qualification time.
else:
               print("You unfortunately don't qualify for any award.")

               
