f = open('input.txt', 'r+')
num_list = []
for line in f:
    num_list.append(line.split(','))
for e in num_list:
    print(e)
f.close()

def minimum(mi):
    minimun = min(num_list)
    return minimum

def maximum(ma):
    maximum = max(num_list)
    return maximum

print(minimum(num_list))
print(maximum(num_list))
