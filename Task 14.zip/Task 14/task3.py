#activity 1
a = 20
while True:
    print(a)
    a -= 1
    if a == 0:
      break

#activity 2
for i in range(0,20):
     if i % 2 == 0:
      print(i)

#activity 3
rows = 5
i = 1
while i <= rows :
    j = 1
    while j <= i:
        print("*", end = " ")
        j += 1
    print()
    i += 1
         
         


