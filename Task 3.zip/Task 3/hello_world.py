name = input("Enter your name: ") #input your name

print(name)

age = input("Enter age: ") #input your age

print(age)

string = 'Hello World'

print("Hello World") #print "Hello World"
