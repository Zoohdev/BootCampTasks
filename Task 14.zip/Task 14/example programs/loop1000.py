# This program prints all the even numbers between 1 and 999.
for num in range(1,1000):
    if num % 2 == 0:
        print(num)
