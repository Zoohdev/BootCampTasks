#Program defines string then capitalizes every alternate character
#define string
string= "interesting task"
#set new string as empty
new_string = ""
#define for loop
for i in range(len(string)): 
   if i % 2==0: 
    new_string+= string[i].upper() 
   else: 
     new_string+= string[i].lower()
print(new_string) 
   
