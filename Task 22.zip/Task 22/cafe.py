#Program calculates stock value of cafe menu items
#Create list of menu
#Create dictionary of stock and price with total as zero
#Use for loop to iterate over stock and price and calculate total
menu = ['Sushi', 'Lasagna', 'Red Wine', 'Mimosa']
total = 0
stock = {1: 45,
         2: 35,
         3: 28,
         4: 65
         }

price = {1: 89,
         2: 135,
         3: 269,
         4: 176
         }

for stock in price:
    total = total + price[stock]
total = float(total)
print("The total value of the stock is R" + (str(total)))
