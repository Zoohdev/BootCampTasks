#input sentence
str_manip = input('Enter a sentence: ')

#prints sentence
print(str_manip)

#calculates length of string
length =len(str_manip)

#prints length of string
print(len(str_manip))

#determines last character of string
last_char = str_manip[-1]

#prints last character of the string
print(last_char)

#replace last character with @
new_string = str_manip.replace(last_char,'@')

#prints a new string with @
print(new_string)
