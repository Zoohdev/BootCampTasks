#define string
a_sentence = "the!quick!brown!fox!jumps!over!the!lazy!dog"

#prints the string
print(a_sentence) 

 #prints out the quick brown fox jumps over the lazy dog
print(a_sentence.replace("!"," "))
 

a_sentence1 = "the quick brown fox jumps over the lazy dog"

#prints THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG
print(a_sentence1.upper())

#reverse text
def reverse(text):
    a = ""
    for i in range(1, len(text) + 1):
        a += text[len(text) - i]
    return a

# prints: GOD YZAL EHT REVO SPMUJ XOF NWORB KCIUQ EHT
print(reverse("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"))









