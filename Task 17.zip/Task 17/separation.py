#Program  prompts for sentence
#Prints each word of input on separate line using index slicing
#define string
string = input("Enter Sentence:")
#use while loop on empty string
while ' ' in string:
    i = string.index(' ')
    print(string[:i])
    string = string[i+1:]
print(string)
